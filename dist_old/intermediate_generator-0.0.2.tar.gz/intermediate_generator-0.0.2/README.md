# Intermediate_generator
The package for creating molecular intermediates, specifically focussed for use in relative binding free energy calculations.
